package com.lokavida.splash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

public class Splash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView logoid = findViewById(R.id.logoId);

        int duration = 10000;

        logoid.animate()
                .alpha(1)
                .rotation(3600)
                .setDuration(duration)
                .withEndAction

        (new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(Splash.this, Welcome.class);
                        startActivity(intent);}
                }).start();


    }
}